package driver;
import java.util.ArrayList;

import client.Client;

public class Main {

	public static void main(String[] args) {
		Client client = new Client();
		
		for (String item: client.getModels()){
			System.out.println(item);
		}
		
		
	}
}
