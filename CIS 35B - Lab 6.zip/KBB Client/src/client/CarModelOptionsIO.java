package client;

import java.util.Scanner;

import model.Automobile;

public class CarModelOptionsIO {

	Automobile auto;
	
	public CarModelOptionsIO(Automobile auto){
		this.auto = auto;
	}
	
	public void chooseOptions(){
		Scanner scanner = new Scanner(System.in);
		System.out.println("Selected Car: " + auto.getMake() + " " + auto.getModel() + " " + auto.getYear() + " Base price: " + auto.getBasePrice());
		while(true){
			System.out.println("Select an option to configure: ");
			for(int i = 0; i < auto.getOptionSetSize(); i++){
				System.out.println(i + ") " + auto.getOptionSetName(i));
			}
			System.out.print("Enter the number of the option you would like to configure: ");
			int optionNum = Integer.parseInt(scanner.nextLine());
			for(int i = 0; i < auto.getArrayOptionsSize(optionNum); i++){
				String optionName = auto.getArrayOptions(optionNum, i);
				if(!optionName.equals("NULL"))
					System.out.println(i + ") " + optionName);
			}
			System.out.print("Enter the number of the option that you want to select: ");
			int selection = scanner.nextInt();
			auto.chooseOptionChoice(auto.getOptionSetName(optionNum), auto.getArrayOptions(optionNum, selection));
			System.out.print("Confirmed.\nWould you like to configure another option? (y/n): ");
			scanner.nextLine();
			String tString = scanner.nextLine();
			if(!tString.toLowerCase().equals("y"))
				break;
		}
	}
	
}
