package client;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Scanner;

import adapter.BuildAuto;
import model.Automobile;

public class Client {

	public Client(){
		
	}
	
	public Automobile getAuto(String key) {
		Socket sock = connect();
		ObjectOutputStream out = null;
		ObjectInputStream in = null;
		try {
			out = new ObjectOutputStream(sock.getOutputStream());
			in = new ObjectInputStream(sock.getInputStream());
			out.writeObject("get options");
			out.writeObject(key);
			Automobile auto = (Automobile) in.readObject();
			sock.close();
			return auto;
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
			try {
				sock.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			return null;
		}
		
	}
	
	public ArrayList<String> getModels() {
		Socket sock = connect();
		ObjectOutputStream out = null;
		ObjectInputStream in = null;
		try {
			out = new ObjectOutputStream(sock.getOutputStream());
			in = new ObjectInputStream(sock.getInputStream());
			out.writeObject("display models");
			ArrayList<String> autoArr = (ArrayList<String>) in.readObject();
			sock.close();
			return autoArr;
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
			try {
				sock.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			return null;
		}
		
	}
	
	public Socket connect() {
		Socket sock = null;
		try {
			sock = new Socket("127.0.0.1", 4444);
		} catch (UnknownHostException e) {
			System.out.println("Unknown host, failed to connect.");
		} catch (IOException e) {
			System.out.println("I/O connection could not be established.");
		}
		return sock;
	}
	
	public void run(){
		System.out.println("Initialized.\nPlease select a command: 'connect' , 'upload' , 'quit'");
		Scanner scanner = new Scanner(System.in);
		Socket sock = null;
		OutputStream out = null;
		ObjectInputStream in = null;
		
		while(true){
			System.out.print("> ");
			String command = scanner.next();
			command = command.toLowerCase();
			switch (command){
			case "connect": 
				try {
					sock = new Socket("127.0.0.1", 4444);
					out = sock.getOutputStream();
					in = new ObjectInputStream(sock.getInputStream());
					System.out.println("Connection to " + sock.getInetAddress() + " successful.");
				} catch (UnknownHostException e) {
					System.out.println("Unknown host, failed to connect.");
				} catch (IOException e) {
					System.out.println("I/O connection could not be established.");
				}
				break;
			case "upload": 
				if(in != null){
					System.out.println("Please enter the file path for the vehicle file you would like to upload.");
					scanner.nextLine();
					String fileName = scanner.nextLine();
					FileInputStream inputStream;
					Properties prop = new Properties();
					try {
						try{
							inputStream = new FileInputStream(fileName);
							prop.load(inputStream);
							ObjectOutputStream outStream = new ObjectOutputStream(out);
							outStream.writeObject(prop);
							try {
								System.out.println(in.readObject());
								Automobile tauto = (Automobile)in.readObject();
								CarModelOptionsIO configure = new CarModelOptionsIO(tauto);
								configure.chooseOptions();
								System.out.println("Here is your completed car:");
								System.out.println(tauto.toString());
							} catch (ClassNotFoundException e) {
								e.printStackTrace();
							}
							outStream.close();
						} catch (FileNotFoundException e) {
							System.out.println(fileName + " does not exist or cannot be found.");
						}	
					} catch (IOException e1) {
						System.out.println("Failed to load properties file.");
						e1.printStackTrace();
					}
				}
				break;
			case "quit":
				System.out.println("Quitting client.");
				scanner.close();
				System.exit(0);
				break;
			default: 
				System.out.println("Please select a command: 'connect' , 'upload' , 'quit'");
				break;
			}
		}
		
	}
	
	
}
