# KBB-Application

**Description**

This application is designed to give similar functionality to KBB.com and is being written as part of CIS 35B.

**Lessons Learned**
--------------------
Version 1
 - Class diagrams
 - Encapsulation
 - Containment
 - Serilization
 - FileIO using BufferedReader and FileReader
 - Component oriented design
 - CRUDP
 - Java Packages
