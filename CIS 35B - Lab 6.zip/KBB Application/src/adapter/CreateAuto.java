package adapter;

public interface CreateAuto {

	void buildAuto(String fileName);
	String printAuto(String modelName);
	
	
}
