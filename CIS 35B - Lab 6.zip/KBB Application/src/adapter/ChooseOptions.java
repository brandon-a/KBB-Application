package adapter;

public interface ChooseOptions {
	 public void chooseOption(String key, String optionSetName, String optionName);
	 
}
