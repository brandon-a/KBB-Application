package adapter;

public class BuildAuto extends ProxyAutomotive implements CreateAuto, UpdateAuto, FixAuto, ChooseOptions {


}
