package server;

public interface AutoServer {

}
