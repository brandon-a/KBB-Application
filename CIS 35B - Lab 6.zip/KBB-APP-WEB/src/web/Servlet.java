package web;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import adapter.*;
import client.Client;
@WebServlet("/")
public class Servlet extends HttpServlet {

	Client client = new Client();
	
    public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException{
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();


        out.println("<HTML>");
        out.println("<HEAD>");
        out.println("<TITLE>");
        out.println("Car Configurator");
        out.println("</TITLE>");
        out.println("</HEAD>");
        out.println("<BODY>");
        out.println("<H1>Welcome to my KBB web app!</H1>");
        out.println("Please select a model to start:");
        out.println("<form action=\"configure\" method=\"get\">");
        out.println("<select name=\"model\">");
        for (String model: client.getModels()){
        	out.print("<option value=\"" + model + "\">" + model + "</option>");
        }
        out.println("</select>");
        out.println("<input type=\"submit\" value=\"Submit\">");
        out.println("</form>");
        out.println("</BODY>");
        out.println("</HTML>");
    }
	
	
}
