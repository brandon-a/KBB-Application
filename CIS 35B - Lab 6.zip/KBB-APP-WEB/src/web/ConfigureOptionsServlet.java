package web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import adapter.BuildAuto;
import client.Client;
import model.Automobile;
import model.Option;
import model.OptionSet;

@WebServlet("/configure")
public class ConfigureOptionsServlet extends HttpServlet {

	Client client = new Client();
	
	 public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException{
		 response.setContentType("text/html");
		 PrintWriter out = response.getWriter();
		 Automobile auto = client.getAuto(request.getParameter("model"));
		 
		 
		 out.println("<html>");
		 out.println("<head>");
		 out.println("<title>Car Configurator</title>");
		 out.println("</head>");
		 out.println("<body>");
		 out.println("<h1>Configure Car</h1>");
		 out.println("<form action=\"result.jsp\" method=\"get\">");
		 out.println("<input type=\"hidden\" name=\"auto\" value=\"" + request.getParameter("model") + "\">");
		 out.println("<table border=1>");
		 out.println("<tr>");
		 out.println("<td><b>Model</b></td>");
		 out.println("<td>" + request.getParameter("model") + "</td>");
		 out.println("</tr>");
		 for (OptionSet set: auto.getOptionSetArr()){
			out.println("<tr>");
			out.println("<td><b>" + set.getName() + "</b></td>");
			out.println("<td><select name=\"" + set.getName() + "\">");
			for (Option opt: set.getOptionArr()){
				if(!opt.getSelection().equals("NULL"))
					out.print("<option value=\"" + opt.getSelection() + "\">" + opt.getSelection() + "</option>");
			}
			out.println("</select></td></tr>");
		 }
		 out.println("</table>");
		 out.println("<input type=\"submit\" value=\"Submit\">");
	     out.println("</form>");
		 out.println("</body>");
		 out.println("</html>");
	 }
	
}
